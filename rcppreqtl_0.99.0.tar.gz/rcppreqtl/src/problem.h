#ifndef PROBLEM_H
#define PROBLEM_H

#include <RcppEigen.h>
#include <cmath>

#if defined(MATLAB) || defined(NDEBUG)
#define EXPECT_NEAR(x, y, z)
#else
#include "../gtest/gtest.h"
#endif /* RELEASE MODE */

#include "meta.h"

namespace cppoptlib {
template<typename T>
class Problem {
 protected:
  
  bool hasLowerBound_ = false;
  bool hasUpperBound_ = false;
  

  Vector<T> lowerBound_;
  Vector<T> upperBound_;


 public: 
  //here we will define data used to optimize parameters
  int nInd;       //number of samples
  int nAse;       //number of allele specific samples
  int nBet;       //number of betas
  double b0 = 0;      //additive effect for a model estimating parent of origin effect (b1)
  double b1 = 0;      //poo effect for a model estimating parent of origin effect (b1)
  double liphi = 0;   //NB phi^-1
  double lphi = 0;    //BB phi^-1  
  int dir = 1;
  Vector<T> trc;  //total read counts for each sample
  Vector<T> trcf;  //log factorial of total read counts for each sample
  //technical two fields
  Vector<T> tmn;  //log mean value for each sample (technical vector - recalculated based on fitted parameters)
  Vector<T> etmn;  //mean value for each sample (technical vector - recalculated based on fitted parameters)
  Vector<T> partmu;  //the part of mean produced by linear part of the model;calculated once per irw iteration X%*%betas
  Vector<T> prob;  //probability of second allele
  
  Vector<T> asn; //allele specific counts from both haplotypes for each sample
  Vector<T> asnp; //allele specific counts from paternal haplotype for each sample
  
  Vector<int> thp;//haplotype information for each sample
  Vector<T> betas;//linear mean structure parameters
  Matrix<T> X;    //design matrix for these betas
  Problem() {}
  ~Problem() {}  

  //passing problem specific parameters
  void setNind(int x) {//total number of individuals
    nInd = x;
  }
  void setNase(int x) {//total number of individuals
    nAse = x;
  }
  void setTRC(Vector<T> x) {
    trc = x;
  }
  void setAS(Vector<T> x) {
    asn = x;
  }
  void setASp(Vector<T> x) {
    asnp = x;
  }
  void setTRCF(Vector<T> x) {
    trcf = x;
    for(int i=0;i<nInd;i++){
      trcf[i] = lgamma(trc[i]+1);
    }
  }

  void setTMN(Vector<T> x) {
    tmn = x;
  }
  void setETMN(Vector<T> x) {
    etmn = x;
  }
  void setProb(Vector<T> x) {
    prob = x;
  }
  Vector<double> updTMNb0(Vector<double> lnpar){
    double b0 = lnpar[0];
    double vals[4] = {0,0,0,0};
    vals[1] = log1p(exp(b0))-log1p(1);
    vals[2] = vals[1];
    vals[3] = b0;

    for(int i=0;i<this->nInd;i++){
      this->tmn[i] = this->partmu[i] + vals[this->thp[i]];
    }
    return tmn;
  }
  Vector<double> updTMNb1(Vector<double> lnpar){
    double b1 = lnpar[0];
    double vals[4] = {0,0,0,0};
    //log1p(exp(b0+b1)) - log1p(exp(b1))
    vals[1] = log1p(exp(b0+b1))-log1p(exp(b1));
    vals[2] = log1p(exp(b0-b1))-log1p(exp(-b1));
    vals[3] = b0;
//    std::cout << b0 << " " << b1 << " " << vals[0] << " "<< vals[1] << " "<< vals[2] << " "<< vals[3] << std::endl;    

    for(int i=0;i<nInd;i++){
      tmn[i] = partmu[i] + vals[thp[i]];
    }    
    return tmn;
  }
  
  void setTHP(Vector<int> x) {
    thp = x;
  }
  //linear
  void setBetas(Vector<T> x){
    betas = x;
  }
  Vector<T> getBetas(){
    return betas;
  }
  /*
  void updBetas(Matrix<T> W){
    betas = W;
  }
  */
  void setNbet(int x){
    nBet = x;
  }

  void setX(Matrix<T> Xm) {
    X = Xm;
  }
  void setPartmu(){
    partmu = X*betas;
  }    
  Vector<T> getPartmu(){
    return partmu;
  }

  int getNind(){
    return nInd;
  }
  int getNase(){
    return nAse;
  }

  void setLiphi(double x){
    liphi = x;
  }
  void setLphi(double x){
    lphi = x;
  }
  void setB0(double x){
    b0 = x;
  }
  void setB1(double x){
    b1 = x;
  }
  double getB0(){
     return b0;
  }
  double getB1(){
     return b1;
  }
  void setDir(int x){
    dir = x;//dir = 1 for liphi, dir = 2 for b0(b1)
  }  

  //
  //
  //generic parameters  
  void setBoxConstraint(Vector<T>  lb, Vector<T>  ub) {
    setLowerBound(lb);
    setUpperBound(ub);
  }

  void setLowerBound(Vector<T>  lb) {
    lowerBound_    = lb;
    hasLowerBound_ = true;
  }

  void setUpperBound(Vector<T>  ub) {
    upperBound_ = ub;
    hasUpperBound_ = true;
  }

  bool hasLowerBound() {
    return hasLowerBound_;
  }

  bool hasUpperBound() {
    return hasUpperBound_;
  }

  Vector<T> lowerBound() {
    return lowerBound_;
  }

  Vector<T> upperBound() {
    return upperBound_;
  }

  /**
   * @brief returns objective value in x
   * @details [long description]
   *
   * @param x [description]
   * @return [description]
   */
  virtual T value(const  Vector<T> &x) = 0;
  /**
   * @brief overload value for nice syntax
   * @details [long description]
   *
   * @param x [description]
   * @return [description]
   */
  T operator()(const  Vector<T> &x) {
    return value(x);
  }
  /**
   * @brief returns gradient in x as reference parameter
   * @details should be overwritten by symbolic gradient
   *
   * @param grad [description]
   */
  virtual void gradient(const  Vector<T> &x,  Vector<T> &grad) {
    finiteGradient(x, grad);
  }

  /**
   * @brief This computes the hessian
   * @details should be overwritten by symbolic hessian, if solver relies on hessian
   */
  virtual void hessian(const Vector<T> & x, Matrix<T> & hessian) {
    finiteHessian(x, hessian);

  }

  virtual bool checkGradient(const Vector<T> & x, int accuracy = 3) {
    // TODO: check if derived class exists:
    // int(typeid(&Rosenbrock<double>::gradient) == typeid(&Problem<double>::gradient)) == 1 --> overwritten
    const int D = x.rows();
    Vector<T> actual_grad(D);
    Vector<T> expected_grad(D);
    gradient(x, actual_grad);
    finiteGradient(x, expected_grad, accuracy);

    bool correct = true;

    for (int d = 0; d < D; ++d) {
      T scale = std::max((std::max(fabs(actual_grad[d]), fabs(expected_grad[d]))), 1.);
      EXPECT_NEAR(actual_grad[d], expected_grad[d], 1e-2 * scale);
      if(fabs(actual_grad[d]-expected_grad[d])>1e-2 * scale)
        correct = false;
    }
    return correct;

  }

  virtual bool checkHessian(const Vector<T> & x, int accuracy = 3) {
    // TODO: check if derived class exists:
    // int(typeid(&Rosenbrock<double>::gradient) == typeid(&Problem<double>::gradient)) == 1 --> overwritten
    const int D = x.rows();
    bool correct = true;

    Matrix<T> actual_hessian = Matrix<T>::Zero(D, D);
    Matrix<T> expected_hessian = Matrix<T>::Zero(D, D);
    hessian(x, actual_hessian);
    finiteHessian(x, expected_hessian, accuracy);
    for (int d = 0; d < D; ++d) {
      for (int e = 0; e < D; ++e) {
        T scale = std::max(static_cast<T>(std::max(fabs(actual_hessian(d, e)), fabs(expected_hessian(d, e)))), (T)1.);
        EXPECT_NEAR(actual_hessian(d, e), expected_hessian(d, e), 1e-1 * scale);
        if(fabs(actual_hessian(d, e)- expected_hessian(d, e))>1e-1 * scale)
        correct = false;
      }
    }
    return correct;

  }

  virtual void finiteGradient(const  Vector<T> &x, Vector<T> &grad, int accuracy = 0) final {
    // accuracy can be 0, 1, 2, 3
    const T eps = 2.2204e-6;
    const size_t D = x.rows();
    const std::vector< std::vector <T>> coeff =
    { {1, -1}, {1, -8, 8, -1}, {-1, 9, -45, 45, -9, 1}, {3, -32, 168, -672, 672, -168, 32, -3} };
    const std::vector< std::vector <T>> coeff2 =
    { {1, -1}, {-2, -1, 1, 2}, {-3, -2, -1, 1, 2, 3}, {-4, -3, -2, -1, 1, 2, 3, 4} };
    const std::vector <T> dd = {2, 12, 60, 840};

    Vector<T> finiteDiff(D);
    for (size_t d = 0; d < D; d++) {
      finiteDiff[d] = 0;
      for (int s = 0; s < 2*(accuracy+1); ++s)
      {
        Vector<T> xx = x.eval();
        xx[d] += coeff2[accuracy][s]*eps;
        finiteDiff[d] += coeff[accuracy][s]*value(xx);
      }
      finiteDiff[d] /= (dd[accuracy]* eps);
    }
    grad = finiteDiff;
  }

  virtual void finiteHessian(const Vector<T> & x, Matrix<T> & hessian, int accuracy = 0) final {
    const T eps = std::numeric_limits<T>::epsilon()*10e7;
    const size_t DIM = x.rows();

    if(accuracy == 0) {
      for (size_t i = 0; i < DIM; i++) {
        for (size_t j = 0; j < DIM; j++) {
          Vector<T> xx = x;
          T f4 = value(xx);
          xx[i] += eps;
          xx[j] += eps;
          T f1 = value(xx);
          xx[j] -= eps;
          T f2 = value(xx);
          xx[j] += eps;
          xx[i] -= eps;
          T f3 = value(xx);
          hessian(i, j) = (f1 - f2 - f3 + f4) / (eps * eps);
        }
      }
    } else {
      /*
        \displaystyle{{\frac{\partial^2{f}}{\partial{x}\partial{y}}}\approx
        \frac{1}{600\,h^2} \left[\begin{matrix}
          -63(f_{1,-2}+f_{2,-1}+f_{-2,1}+f_{-1,2})+\\
          63(f_{-1,-2}+f_{-2,-1}+f_{1,2}+f_{2,1})+\\
          44(f_{2,-2}+f_{-2,2}-f_{-2,-2}-f_{2,2})+\\
          74(f_{-1,-1}+f_{1,1}-f_{1,-1}-f_{-1,1})
        \end{matrix}\right] }
      */
      Vector<T> xx;
      for (size_t i = 0; i < DIM; i++) {
        for (size_t j = 0; j < DIM; j++) {

          T term_1 = 0;
          xx = x.eval(); xx[i] += 1*eps;  xx[j] += -2*eps;  term_1 += value(xx);
          xx = x.eval(); xx[i] += 2*eps;  xx[j] += -1*eps;  term_1 += value(xx);
          xx = x.eval(); xx[i] += -2*eps; xx[j] += 1*eps;   term_1 += value(xx);
          xx = x.eval(); xx[i] += -1*eps; xx[j] += 2*eps;   term_1 += value(xx);

          T term_2 = 0;
          xx = x.eval(); xx[i] += -1*eps; xx[j] += -2*eps;  term_2 += value(xx);
          xx = x.eval(); xx[i] += -2*eps; xx[j] += -1*eps;  term_2 += value(xx);
          xx = x.eval(); xx[i] += 1*eps;  xx[j] += 2*eps;   term_2 += value(xx);
          xx = x.eval(); xx[i] += 2*eps;  xx[j] += 1*eps;   term_2 += value(xx);

          T term_3 = 0;
          xx = x.eval(); xx[i] += 2*eps;  xx[j] += -2*eps;  term_3 += value(xx);
          xx = x.eval(); xx[i] += -2*eps; xx[j] += 2*eps;   term_3 += value(xx);
          xx = x.eval(); xx[i] += -2*eps; xx[j] += -2*eps;  term_3 -= value(xx);
          xx = x.eval(); xx[i] += 2*eps;  xx[j] += 2*eps;   term_3 -= value(xx);

          T term_4 = 0;
          xx = x.eval(); xx[i] += -1*eps; xx[j] += -1*eps;  term_4 += value(xx);
          xx = x.eval(); xx[i] += 1*eps;  xx[j] += 1*eps;   term_4 += value(xx);
          xx = x.eval(); xx[i] += 1*eps;  xx[j] += -1*eps;  term_4 -= value(xx);
          xx = x.eval(); xx[i] += -1*eps; xx[j] += 1*eps;   term_4 -= value(xx);

          hessian(i, j) = (-63 * term_1+63 * term_2+44 * term_3+74 * term_4)/(600.0 * eps * eps);

        }
      }
    }

  }

};
}

#endif /* PROBLEM_H */
